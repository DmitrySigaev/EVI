MATLAB GUI for simple phenocam analysis.
