function e = corrsub(a,b,se)
%CORRSUB 2-D correlation in the frequency domain with removal of large
%areas of high correlation
% E = CORRSUB(A,B,SE) performs the correlation of a mask, B, with image A,
% using DFTCORR.  The correlation image then has regions smaller than
% structure SE removed.  This filtered correlation image is subtracted from
% the original, leaving only the small regions, the best fit region(s) for
% the mask.
%
%--------------------------------------------------------------------------
% Created By: Donald M. Aubrecht
% Date Modified: 8 November 2012
%--------------------------------------------------------------------------

c = dftcorr(a,b); % use DFTCORR to find correlation of mask, B, with image, A
d = imopen(c,se); % eliminate objects in correlation less than region defined by SE (use se = strel)
e = c-d; %subtract images to leave only small regions from original correlation