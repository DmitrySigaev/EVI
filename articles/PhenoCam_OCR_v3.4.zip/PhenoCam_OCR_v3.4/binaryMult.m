function maxNorm = binaryMult(a,b)
%binaryMult matix multiplication routine.
% MAX = BINARYMULT(A,B) takes two 2-D binary matrices and steps matrix B 
% around A and determines the sum of the product of the overlapping 
% elements. B must be smaller than or equal to A in both dimensions. The
% function returns the maximum sum obtained, normalized by the sum of
% matrix B. A value of -1 is returned if B does not meet the size
% requirements.
%
%--------------------------------------------------------------------------
% Created By: Donald M. Aubrecht
% Date Modified: 8 November 2012
%--------------------------------------------------------------------------

max = 0;
maxNorm = 0;
sumB = sum(b(:));
sizeA = size(a);
sizeB = size(b);

if ((sizeA(1) >= sizeB(1)) && (sizeA(2) >= sizeB(2)))
    
    rowIter = sizeA(1)-sizeB(1)+1;
    colIter = sizeA(2)-sizeB(2)+1;
    
    for ii = 1:rowIter
        for jj = 1:colIter
            c = a(ii:ii+sizeB(1)-1,jj:jj+sizeB(2)-1) == b;
            cSum = sum(c(:));
            if cSum > max
                max = cSum;
            end
        end
    end
    
    maxNorm = max/(sizeB(1)*sizeB(2));
    
else
    maxNorm = -1;
end