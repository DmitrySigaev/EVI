function phenocamOCR(path,refPath)
%PHENOCAMOCR retrieves exposure value from phenoCam JPEG images.
% PHENOCAMOCR(PATH,REFPATH) accepts two path strings, either
% relative or absolute and outputs a text document containing filenames and
% image exposure values.  PATH denotes the location of JPEG images to be
% analyzed.  The function does not do recursive search through folder 
% tiers, so only the JPEGs housed in PATH will be analyzed.  To work with 
% the standard PhenoCam repository structure, a wrapper script must written
% that feeds each month's directory to PHENOCAMOCR.  REFPATH denotes the 
% location of reference images, namely "Exposure:" and the numbers 0-9.  
% For each image in PATH, the exposure stamp on the image will be read and 
% placed next to the filename on a line of the output text file.  The text 
% file and images of the exposure are saved in a new folder in PATH.  
% Exposure value of -1 corresponds to no acceptable fits during the OCR 
% routine; either correlation or filtering/thresholding did not work 
% correctly.  Exposure value of -2 corresponds to cropping error; this 
% indicates that the correlation did not work correctly.
%
% Support functions required: BINARYMULT, CORRSUB, DFTCORR, GSCALE
%
% This code shoud be platform independent, but has only been tested on
% Windows 7 and Ubuntu 10.04LTS running Matlab 7.12.0 (R2011a), a Linux
% cluster running R2011a, Windows Server 2008 running R2012a, and Mac OS
% 10.9 running R2014a
%
%--------------------------------------------------------------------------
% Created By: Donald M. Aubrecht
% Date Modified: 1 December 2012
% Version: 3.4
%--------------------------------------------------------------------------
% Version History:
%   1.0 - 8 November 2012
%   1.1 - 12 November 2012
%       fix issue with missing characters in some harvardbarn images
%   2.0 - 13 November 2012
%       account for smaller reference text size on smaller image sizes
%   3.0 - 16 November 2012
%       determine which reference size to use (1 or 2 pixel width
%       characters) based on infostamp size
%   3.1 - 19 November 2012
%       to help address thresholding vs cropping issues, original frame
%       crop is stored along with thresholded crop
%   3.2 - 20  November 2012
%       tophat processing to help threshold exposure characters in cropped
%       region
%   3.3 - 28 November 2012
%       eliminate variation in blue bar overlay
%       code determines reference size on a per image basis
%   3.4 - 1 December 2012
%       updated for parallelized processing
%--------------------------------------------------------------------------



%% USER CHANGEABLE PARAMETERS
%---- You shouldn't normally have to change any of these -----------------%
%
singleImage = false; %set to true to analyze only first image in a directory
displayImgs = false; %set to true to display image for each processing step
warning off MATLAB:MKDIR:DirectoryExists %turn off warning about save directory already existing
%
%-------------------------------------------------------------------------%



%% INITIAL SETUP

%Log current folder, determine full paths for analysis and reference
%folders. Make save folder and open text file for output. If the text file
%exists, data is appended to the end of the file.
startFolder = pwd;
folder = cd(cd(path));
refFolder = cd(cd(refPath));
[pathstr, folderstr, extension] = fileparts(folder);
saveFolder = [folder '/exposureCrops'];
mkdir(saveFolder);
listing = dir(strcat(folder,'/*.jpg'));
numFiles = length(listing);


%Load in reference images and convert to binary
exposureOne = rgb2gray(imread(strcat(refFolder,'/exposure.tif')));
one = rgb2gray(imread(strcat(refFolder,'/one.tif'))).^2; %square elements to enhance contrast
one = im2bw(one,graythresh(one));
two = rgb2gray(imread(strcat(refFolder,'/two.tif'))).^2;
two = im2bw(two,graythresh(two));
three = rgb2gray(imread(strcat(refFolder,'/three.tif'))).^2;
three = im2bw(three,graythresh(three));
four = rgb2gray(imread(strcat(refFolder,'/four.tif'))).^2;
four = im2bw(four,graythresh(four));
five = rgb2gray(imread(strcat(refFolder,'/five.tif'))).^2;
five = im2bw(five,graythresh(five));
six = rgb2gray(imread(strcat(refFolder,'/six.tif'))).^2;
six = im2bw(six,graythresh(six));
seven = rgb2gray(imread(strcat(refFolder,'/seven.tif'))).^2;
seven = im2bw(seven,graythresh(seven));
eight = rgb2gray(imread(strcat(refFolder,'/eight.tif'))).^2;
eight = im2bw(eight,graythresh(eight));
nine = rgb2gray(imread(strcat(refFolder,'/nine.tif'))).^2;
nine = im2bw(nine,graythresh(nine));
zero = rgb2gray(imread(strcat(refFolder,'/zero.tif'))).^2;
zero = im2bw(zero,graythresh(zero));
halfSize = false; %initialize variable to indicate if scaling is necessary
aOne = 1; %area scale factor for pixel exclusions

%Create small size reference images (1 pixel wide characters)
exposureHalf = padarray(imresize(exposureOne,0.5,'nearest'),[1 1],'pre');
oneHalf = imresize(one,0.5,'nearest');
twoHalf = imresize(two,0.5,'nearest');
threeHalf = imresize(three,0.5,'nearest');
fourHalf = imresize(four,0.5,'nearest');
fiveHalf = imresize(five,0.5,'nearest');
sixHalf = imresize(six,0.5,'nearest');
sevenHalf = imresize(seven,0.5,'nearest');
eightHalf = imresize(eight,0.5,'nearest');
nineHalf = imresize(nine,0.5,'nearest');
zeroHalf = imresize(zero,0.5,'nearest');
aHalf = 0.25; %area scale factor for pixel exclusions


%Create structuring element for filtering out small correlation peaks when
%finding "Exposure"
se = strel('square',2); %square area with 2 pixel width

% %Create structuring element for tophat transform of cropped image
% se2 = strel('disk',5); %structuring element is larger than numerical characters


%Determine reference image sizes
expOneSize = size(exposureOne);expHalfSize = size(exposureHalf);
oneSize = size(one);oneHalfSize = size(oneHalf);
twoSize = size(two);twoHalfSize = size(twoHalf);
threeSize = size(three);threeHalfSize = size(threeHalf);
fourSize = size(four);fourHalfSize = size(fourHalf);
fiveSize = size(five);fiveHalfSize = size(fiveHalf);
sixSize = size(six);sixHalfSize = size(sixHalf);
sevenSize = size(seven);sevenHalfSize = size(sevenHalf);
eightSize = size(eight);eightHalfSize = size(eightHalf);
nineSize = size(nine);nineHalfSize = size(nineHalf);
zeroSize = size(zero);zeroHalfSize = size(zeroHalf);


%Determine largest footprint for reference numerical character images
refOneSize(1) = max([oneSize(1),twoSize(1),threeSize(1),fourSize(1),fiveSize(1),sixSize(1),sevenSize(1),eightSize(1),nineSize(1),zeroSize(1)])+4;
refOneSize(1) = refOneSize(1) + mod(-refOneSize(1),2); %round refOneSize rows up to nearest 2 to ensure it is even
refOneSize(2) = max([oneSize(2),twoSize(2),threeSize(2),fourSize(2),fiveSize(2),sixSize(2),sevenSize(2),eightSize(2),nineSize(2),zeroSize(2)])+4;
refOneSize(2) = refOneSize(2) + mod(-refOneSize(2),2); %round refOneSize cols up to nearest 2 to ensure it is even

refHalfSize(1) = max([oneHalfSize(1),twoHalfSize(1),threeHalfSize(1),fourHalfSize(1),fiveHalfSize(1),sixHalfSize(1),sevenHalfSize(1),eightHalfSize(1),nineHalfSize(1),zeroHalfSize(1)])+4;
refHalfSize(1) = refHalfSize(1) + mod(-refHalfSize(1),2); %round refHalfSize rows up to nearest 2 to ensure it is even
refHalfSize(2) = max([oneHalfSize(2),twoHalfSize(2),threeHalfSize(2),fourHalfSize(2),fiveHalfSize(2),sixHalfSize(2),sevenHalfSize(2),eightHalfSize(2),nineHalfSize(2),zeroHalfSize(2)])+4;
refHalfSize(2) = refHalfSize(2) + mod(-refHalfSize(2),2); %round refHalfSize cols up to nearest 2 to ensure it is even

%Create arrays of numerical characters expressed as words, digits, and
%binary images
refNames = {'one' 'two' 'three' 'four' 'five' 'six' 'seven' 'eight' 'nine' 'zero'};
refNumsArray = [1 2 3 4 5 6 7 8 9 0];
refOneNums(1).BW = one;
refOneNums(2).BW = two;
refOneNums(3).BW = three;
refOneNums(4).BW = four;
refOneNums(5).BW = five;
refOneNums(6).BW = six;
refOneNums(7).BW = seven;
refOneNums(8).BW = eight;
refOneNums(9).BW = nine;
refOneNums(10).BW = zero;
refHalfNums(1).BW = oneHalf;
refHalfNums(2).BW = twoHalf;
refHalfNums(3).BW = threeHalf;
refHalfNums(4).BW = fourHalf;
refHalfNums(5).BW = fiveHalf;
refHalfNums(6).BW = sixHalf;
refHalfNums(7).BW = sevenHalf;
refHalfNums(8).BW = eightHalf;
refHalfNums(9).BW = nineHalf;
refHalfNums(10).BW = zeroHalf;


%Determine minimum pixels in reference character for image filtering later
minPixels = 0;
for ii = 1:length(refOneNums)
    numPixels = sum(refOneNums(ii).BW(:));
    if (numPixels > minPixels)
        minPixels = numPixels;
    end
end
minPixels = minPixels + 20; %Add 20 pixels to account for slight thresholding differences


%Create storage arrays for exposure value
results = [];
finalString = cell(1,numFiles);


%Clean up unused variables
clear one two three four five six seven eight nine zero
clear oneSize twoSize threeSize fourSize fiveSize sixSize sevenSize eightSize nineSize zeroSize
clear oneHalf twoHalf threeHalf fourHalf fiveHalf sixHalf sevenHalf eightHalf nineHalf zeroHalf
clear oneHalfSize twoHalfSize threeHalfSize fourHalfSize fiveHalfSize sixHalfSize sevenHalfSize eightHalfSize nineHalfSize zeroHalfSize

%% ANALYZE EACH IMAGE IN PATH

if singleImage %only analyze first image in directory if set to true
    numFiles = 1;
end

% zz = 0;
% h = waitbar(zz/numFiles,'Processing PhenoCam Images...');

if matlabpool('size') == 0 %check to see if local pool is already open
    matlabpool open %open default number of pools
end

%Parallel process the image dataset
parfor zz = 1:numFiles
    
    folderLoop = folder;
    saveFolderLoop = saveFolder;
    refNumsArrayLoop = refNumsArray;
    
    %Open file and get image size
    filename = listing(zz).name;
    filenameShort = filename(1:length(filename)-4);
    img = imread(strcat(folderLoop,'/',filename));
    imgSize = size(img);
    
    
    %Isolate red, green, and blue channels
    imgRed = img(:,:,1);
    imgGreen = img(:,:,2);
    imgBlue = img(:,:,3);
    
%     %Find "Exposure:" using red*green*blue
%     imgRGB = uint8(((double(imgRed)/255).*(double(imgGreen)/255).*(double(imgBlue)/255))*255);
%     imgCorrelate = corrsub(imgRGB,exposure,se);
%     [expRow,expCol] = find(imgCorrelate == max(imgCorrelate(:))); %Indices locating upper left corner of "Exposure"

    %Find "Exposure:" using uniformly colored blue bar (blue bar over white
    %is approximately R=90, G=95, B=135, blue bar over black is
    %approximately R=25, G=30, B=65).
    imgRedLevelled = imgRed - 90;
    imgGreenLevelled = imgGreen - 95;
    imgBlueLevelled = imgBlue - 135;
    imgRedLevelled = imgRedLevelled + 170;
    imgGreenLevelled = imgGreenLevelled + 175;
    imgBlueLevelled = imgBlueLevelled + 170;
    imgLevelled = cat(3,imgRedLevelled,imgGreenLevelled,imgBlueLevelled);
    imgLevelled2 = rgb2gray(imgLevelled);
    
    %Determine size of reference images to use
    imgCorrelateOne = corrsub(imgLevelled2,exposureOne,se);
    imgCorrelateHalf = corrsub(imgLevelled2,exposureHalf,se);
    imgCorrelate = zeros(size(imgLevelled2));
    if max(imgCorrelateOne(:)) > max(imgCorrelateHalf(:))
        imgCorrelate = imgCorrelateOne;
        maxValue = max(imgCorrelateOne(:));
        exposure = exposureOne;
        expSize = expOneSize;
        a = aOne;
        refSize = refOneSize;
        refNums = refOneNums;
    else
        imgCorrelate = imgCorrelateHalf;
        maxValue = max(imgCorrelateHalf(:));
        exposure = exposureHalf;
        expSize = expHalfSize;
        a = aHalf;
        refSize = refHalfSize;
        refNums = refHalfNums;
    end
    
    [expRow,expCol] = find(imgCorrelate == maxValue); %Indices locating upper left corner of "Exposure"

    %Use try/catch to prevent cropping and other errors from stopping
    %analysis.  Exposure value of -1 corresponds to no acceptable fits
    %during OCR routing.  Exposure value of -2 corresponds to cropping
    %error; this indicates that the correlation did not work correctly.
    try
        
        %Crop image to the region following the word "Exposure" to isolate
        %exposure value
        imgCrop = imgLevelled2(expRow:expRow+expSize(1),expCol+expSize(2):imgSize(2));

        %Threshold image
%         imgCrop2 = imtophat(imgCrop,se2);
%         imgCropBW = im2bw(imgCrop2,graythresh(imgCrop2));
        imgCropBW = im2bw(imgCrop,graythresh(imgCrop));
        
        
        %Pad image, then find connected areas to isolate each character for OCR
        imgCropBWFilterPad = padarray(imgCropBW,[20 20]); %Pad with 20 black pixels on each edge of the image
        [L,num(zz)] = bwlabel(imgCropBWFilterPad,8);
        S = regionprops(L,'Area','Centroid','BoundingBox'); %Find centroids of all connected regions
        counter = 1;
        
        
        %Step through regions to determine if they are a character, and if so,
        %which character
        for yy=1:length(S)
            
            if (S(yy).Area >= 8*a) && (S(yy).Area <= 2*minPixels*a) %only process if region has more than 2 equivalent scaled pixels and less than two connected characters
                charCentr = round(S(yy).Centroid); %centroid given as [c,r]
                bestChar = -1; %reset best-fit character value holder
                
                if (charCentr(1) < 6*refSize(2)) %require centroid of region be within 6 reference file widths from the end of "Exposure"
                    
                    if S(yy).BoundingBox(3) >= 1.1*(refSize(2)-4) %if region is wider than 110% of reference character width split into subregions
                        
                        subregions = round(S(yy).BoundingBox(3)/(refSize(2)-4)); %determine number of subregions
                        
                        for xx=1:subregions
                            
                            subCentrCol = round(S(yy).BoundingBox(1))+(xx-0.5)*(refSize(2)-4);
                            
                            charCrop = imgCropBWFilterPad(charCentr(2)-refSize(1)/2:charCentr(2)+refSize(1)/2,subCentrCol-refSize(2)/2:subCentrCol+refSize(2)/2);
                            
                            value = zeros(1,10); %reset correlation value storing array for each region to be analyzed
                            for ww=1:length(refNums) %step through all reference characters
                                value(ww) = binaryMult(charCrop,refNums(ww).BW);
                            end
                            
                            bestChar = find((value>0.95)); %accept match to character if fit is better than 95%
                            if bestChar ~= -1
                                results(counter) = refNumsArrayLoop(bestChar); %store indices and best-fit character
                                counter = counter + 1;
                                bestChar = -1; %reset best-fit character value holder
                            end
                        end
                        
                    else
                        charCrop = imgCropBWFilterPad(charCentr(2)-refSize(1)/2:charCentr(2)+refSize(1)/2,charCentr(1)-refSize(2)/2:charCentr(1)+refSize(2)/2);
                        
                        value = zeros(1,10); %reset correlation value storing array for each region to be analyzed
                        for xx=1:length(refNums) %step through all reference characters
                            value(xx) = binaryMult(charCrop,refNums(xx).BW);
                        end
                        
                        bestChar = find((value>0.95)); %accept match to character if fit is better than 95%
                        if bestChar ~= -1
                            results(counter) = refNumsArrayLoop(bestChar); %store indices and best-fit character
                            counter = counter + 1;
                            bestChar = -1; %reset best-fit character value holder
                        end
                    end
                end
            end
            
        end
        
        
        %After all regions have been stepped through, prepare results to be
        %output to text file.
        if isempty(results)
            textNums = -1;
        else
            textNums = results; %concatenate best-fit characters
        end
        
        
        %Concatenate string of filename and exposure value, then write to
        %file. Write cropped exposure from image to file.
        outputString = [filenameShort ' - '];
        finalString{zz} = [outputString strrep(num2str(textNums),' ','') '\r\n'];
%         imwrite(imgLevelled2,strcat(saveFolderLoop,'/',filenameShort,'_levelled.tif'),'tif','Compression','none');
%         imwrite(imgCrop,strcat(saveFolderLoop,'/',filenameShort,'_origCrop.tif'),'tif','Compression','none');
        imwrite(imgCropBWFilterPad,strcat(saveFolderLoop,'/',filenameShort,'_crop.tif'),'tif','Compression','none');
        results = []; %clear results variable
        
        
%         %Update waitbar
%         waitbar(zz/numFiles);
        
        
        %Display images if user has requested
        if displayImgs %show image of each processing step, if set to true
            imshow(img)
            figure; imshow(imgRGB)
            figure; imshow(gscale(imgCorrelate))
            figure; imshow(imgCrop)
            figure; imshow(imgCrop2)
            figure; imshow(imgCropBW)
            figure; imshow(imgCropBWFilterPad)
        end
        
        
        
    catch err %if cropping error occurs don't let loop get interrupted
        
        if ~isempty(err)
            textNums = -2; %exposure value for image cropping error
            outputString = [filenameShort ' - '];
            finalString{zz} = [outputString strrep(num2str(textNums),' ','') '\r\n'];
        end
    end
    
end


%% CLEAN UP

% close(h);
matlabpool close
fid = fopen([folderstr '.txt'],'a+');
for yy = 1:numFiles
    fprintf(fid,finalString{yy});
end
fclose(fid); %close output text file
movefile([folderstr '.txt'], [folder '/' folderstr '.txt']); %move text file to PATH location
% cd(startFolder); % return to initial folder that houses PHENOCAMPROCESSING and support functions